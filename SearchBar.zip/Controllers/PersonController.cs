﻿using DemoCRUD.Data;
using DemoCRUD.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace DemoCRUD.Controllers
{
    public class PersonController : Controller
    {
        private readonly PersonContext _context;
        private readonly IWebHostEnvironment _hostEnironment;
        public PersonController(PersonContext context, IWebHostEnvironment hostEnvironment)
        {
            _context = context;
            _hostEnironment = hostEnvironment;
        }

        public async Task<IActionResult> Index(string SearchText)
        {
            ViewData["CurrentFilter"] = SearchText;
            var person = from p in _context.Person select p;
            if(!String.IsNullOrEmpty(SearchText))
            {
                person = person.Where(p => p.PersonName.Contains(SearchText));
            }
            return View(person);
        }

    public IActionResult Create()
		{
            return View();
		}

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Person person)
        {
            string filename = Uploadfile(person);
            var p = new Person
            {
                PersonName = person.PersonName,
                PersonAddress = person.PersonAddress,
                ImageName = filename
            };
   
                _context.Person.Add(p);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
			
		}

        private string Uploadfile(Person p)
        {
            string filename = null;
            if(p.ImageFile != null)
            {
                string uploadDir = Path.Combine(_hostEnironment.WebRootPath, "images");
                filename = Guid.NewGuid().ToString() + "-" + p.ImageFile.FileName;
                string filePath = Path.Combine(uploadDir, filename);
                using(var fileStream=new FileStream(filePath, FileMode.Create))
                {
                    p.ImageFile.CopyTo(fileStream);
                }
            }
            else
            {
                filename = Person.ImageName;
            }
            return filename;
        }

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || id <= 0) return BadRequest();
            var person = await _context.Person.FirstOrDefaultAsync(c => c.PersonID == id);
            if(person == null) return NotFound();

            _context.Person.Remove(person);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));

        }

        public async Task<IActionResult> Edit(int? id)
        {
            if(id== null || id <= 0) return BadRequest();
            var person = await _context.Person.FirstOrDefaultAsync(c => c.PersonID == id);
            if( person == null) return NotFound(); 
            return View(person);

        }

        [HttpPost]
        public  async Task<IActionResult> Edit(int id,Person person)
        {
            var p =await _context.Person.FirstOrDefaultAsync(c => c.PersonID == id);
            p.PersonName = person.PersonName;
            p.PersonAddress = person.PersonAddress;
            if(person.ImageName != null)
            {
                string filepath = Path.Combine(_hostEnironment.WebRootPath, "images", person.PersonName);
                System.IO.File.Delete(filepath);

            }

            p.ImageName = Uploadfile(person);
            _context.Update(p);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));

        }

        public async Task<IActionResult> Detail(int? id)
        {
            if (id == null || id <= 0) return BadRequest();
            var person = await _context.Person.FirstOrDefaultAsync(c => c.PersonID == id);
            if (person == null) return NotFound();
            return View(person);

        }

    }
}
