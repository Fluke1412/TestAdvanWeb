﻿using DemoWebAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace DemoWebAPI.Data
{
    public class IssueDbContex:DbContext
    {
        public IssueDbContex(DbContextOptions<IssueDbContex>option):base(option)
        {

        }
        public DbSet<Issue> Issues { get; set; }
    }
}
